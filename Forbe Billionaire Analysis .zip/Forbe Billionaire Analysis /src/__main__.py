# __main__.py in billionaire_analysis package

# todo : add the code for the main function
import sys
from .data_summary import DataSummary
from .eda import ExploratoryDataAnalysis


def main():
    if len(sys.argv) > 1:
        command = sys.argv[1]
        if command == 'data_summary':
            # Execute Data Summary tasks
            print("Running Data Summary Module")
    

        elif command == 'eda':
            # Execute Exploratory Data Analysis tasks
            print("Running EDA Module")
           

        elif command == 'inference':
            # Execute Inference tasks
            print("Running Inference Module")
        

        else:
            print(f"Unknown command: {command}")
    else:
        print("No command provided")

if __name__ == "__main__":
    main()
