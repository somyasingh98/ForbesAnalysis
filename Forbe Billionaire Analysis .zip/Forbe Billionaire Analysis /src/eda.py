# This module contains classes for cleaning data and performing exploratory data analysis on options trading datasets.


import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import matplotlib.dates as mdates


class DataCleaner:
    """
    A class used for cleaning and preparing data for analysis.

    Attributes
    ----------
    data : DataFrame
        a DataFrame containing the data to be cleaned

    Methods
    -------
    analyze_null_values()
        Analyzes the pattern of null values in the data.
    clean_column_names()
        Cleans the column names by removing unwanted characters.
    drop_columns(columns_to_drop)
        Drops specified columns from the DataFrame.
    convert_to_numeric(columns, errors='coerce')
        Converts specified columns to numeric data type.
    handle_null_values(strategy='drop', columns=None)
        Handles null values based on the specified strategy.
    """

    def __init__(self, data):
        """
        Parameters
        ----------
        data : DataFrame
            The DataFrame to be cleaned.
        """
        self.data = data

    def analyze_null_values(self):
        """
        Analyzes the pattern of null values in the DataFrame.

        Returns
        -------
        Series
            A Series displaying the number of null values in each column.
        """
        return self.data.isnull().sum()

    def clean_column_names(self):
        """
        Cleans the column names by removing leading and trailing spaces and square brackets.
        """
        self.data.columns = self.data.columns.str.strip().str.replace(
            "[\[\]]", "", regex=True
        )

    def drop_columns(self, columns_to_drop):
        """
        Drops specified columns from the DataFrame.

        Parameters
        ----------
        columns_to_drop : list of str
            List of column names to be dropped.
        """
        self.data.drop(columns=columns_to_drop, inplace=True, errors="ignore")

    def convert_to_numeric(self, columns, errors="coerce"):
        """
        Converts specified columns to numeric data type.

        Parameters
        ----------
        columns : list of str
            List of column names to be converted.
        errors : str, optional
            Specifies how to handle errors (default is 'coerce').
        """
        for column in columns:
            self.data[column] = pd.to_numeric(self.data[column], errors=errors)

    def convert_to_datetime(self, columns):
        """
        Converts specified columns to datetime data type.

        Parameters
        ----------
        columns : list of str
            List of column names to be converted.
        errors : str, optional
            Specifies how to handle errors (default is 'coerce').
        """
        for column in columns:
            self.data[column] = pd.to_datetime(self.data[column])
        return self.data

    def handle_null_values(self, strategy="drop", fill_method="mean", columns=None):
        """
        Handles null values based on the specified strategy.

        Parameters
        ----------
        strategy : str, optional
            Strategy to handle null values ('drop' or 'fill', default is 'drop').
        fill_method : str, optional
            Method to fill null values ('mean', 'median', 'mode', default is 'mean').
        columns : list of str, optional
            Specific columns to apply the strategy on (default is None, applied to all columns).
        """
        if strategy == "drop":
            if columns:
                self.data.dropna(subset=columns, inplace=True)
            else:
                self.data.dropna(inplace=True)
        elif strategy == "fill":
            if columns:
                for column in columns:
                    if fill_method == "mean":
                        self.data[column].fillna(self.data[column].mean(), inplace=True)
                    elif fill_method == "median":
                        self.data[column].fillna(
                            self.data[column].median(), inplace=True
                        )
                    elif fill_method == "mode":
                        self.data[column].fillna(
                            self.data[column].mode()[0], inplace=True
                        )
            else:
                for column in self.data:
                    if fill_method == "mean":
                        self.data[column].fillna(self.data[column].mean(), inplace=True)
                    elif fill_method == "median":
                        self.data[column].fillna(
                            self.data[column].median(), inplace=True
                        )
                    elif fill_method == "mode":
                        self.data[column].fillna(
                            self.data[column].mode()[0], inplace=True
                        )

    def save_cleaned_data(self, filename):
        """
        Save the cleaned data to a CSV file.

        Parameters:
        filename (str): The name of the file where the data should be saved.
        """
        try:
            self.data.to_csv(filename, index=False)
            print(f"Data successfully saved to {filename}")
        except Exception as e:
            print(f"An error occurred while saving the data: {e}")



class ExploratoryDataAnalysis:
    """
    The ExploratoryDataAnalysis class provides functionalities for
    performing initial exploration on options trading data. It includes methods for
    generating summary statistics, creating various plots, and analyzing trends within the data.

    Attributes:
    data (DataFrame): A pandas DataFrame containing the options trading data.

    Methods:
    summary_statistics():
        Compute and return summary statistics for the dataset.
    plot_iv_behavior(column, title):
        Plot the implied volatility over time for a specified column.
    plot_price_and_iv_trends():
        Plot trends over time for Call and Put Option Prices and their Implied Volatilities.
    plot_price_and_iv_trends_matplotlib():
        Similar to plot_price_and_iv_trends but uses Matplotlib for plotting.
    histogram_matplotlib(column, bins, title):
        Create a histogram for a specified column using Matplotlib.
    """

    def __init__(self, data):
        """
        Initialize the ExploratoryDataAnalysis object with a dataset.

        Parameters:
        data (DataFrame): The dataset to be analyzed.
        """
        self.data = data

    def summary_statistics(self):
        """
        Generate summary statistics for the dataset.

        This method computes summary statistics for all columns in the dataset.
        It includes measures such as mean, standard deviation, min, max for numeric columns,
        and counts, unique values, frequency for categorical columns.

        Returns:
        DataFrame: A DataFrame containing the summary statistics.
        """
        return self.data.describe(include="all", datetime_is_numeric=True)
    
    
    def plot_age_distribution(self, df, title="Age Distribution using Matplotlib"):
        """
        Plots the behavior of Implied Volatility over time using both Matplotlib and Seaborn.

        Parameters:
        column (str): The column representing Implied Volatility.
        title (str): The title of the plot.
        """
        # Check if the column exists in the DataFrame
        # Setting style for Seaborn
        sns.set_style("whitegrid")

        # Histogram for age using Matplotlib
        plt.hist(df['age'].dropna(), bins=30, edgecolor='black')
        plt.title(title)
        plt.xlabel('Age')
        plt.ylabel('Frequency')
        plt.show()
    
        
    def plot_net_worth(self, df, title="Net Worth Distribution"):
        """
        Plots the net worth distribution using Matplotlib.

        Parameters:
        title (str): The title of the plot.
        """
        # Check if the column exists in the DataFrame
        # Setting style for Seaborn
        sns.set_style("whitegrid")

        # Histogram for net_worth using Matplotlib
        plt.hist(df['net_worth'].dropna(), bins=30, edgecolor='black')
        plt.title(title)
        plt.xlabel('Net Worth (in billions)')
        plt.ylabel('Frequency')
        plt.show()
        
    def plot_top_10_bar(self, df, title, xlabel, ylabel):
        df['country'].value_counts().head(10).plot(kind='bar')
        plt.title(title)
        plt.xlabel(xlabel)
        plt.ylabel(ylabel)
        plt.show()
        
    def net_worth_vs_countries(self, df, title, xlabel, ylabel):
        top_countries = df['country'].value_counts().head(10).index
        df_top_countries = df[df['country'].isin(top_countries)]
        df_top_countries.boxplot(column='net_worth', by='country', vert=False, grid=True, figsize=(10,8))
        plt.title(title)
        plt.xlabel(xlabel)
        plt.ylabel(ylabel)
        plt.suptitle('')  # Suppress the automatic title
        plt.show()
        
        
        
    

    