# from sklearn.model_selection import train_test_split, cross_val_score
# from sklearn.ensemble import RandomForestRegressor
# from sklearn.pipeline import Pipeline, make_pipeline
# from sklearn.preprocessing import StandardScaler, OneHotEncoder
# from sklearn.compose import ColumnTransformer
# from sklearn.metrics import mean_squared_error, r2_score
# import numpy as np
# import pandas as pd

# class Model:
#     def __init__(self, data, target, categorical_features, numerical_features):
#         self.data = data
#         self.target = target
#         self.categorical_features = categorical_features
#         self.numerical_features = numerical_features

#     def build_model(self):
#         # Separate the features and the target variable
#         X = self.data.drop(columns=[self.target])
#         y = self.data[self.target]

#         # Create a column transformer for preprocessing
#         preprocessor = ColumnTransformer(
#             transformers=[
#                 ('num', StandardScaler(), self.numerical_features),
#                 ('cat', OneHotEncoder(handle_unknown='ignore'), self.categorical_features)
#             ])

#         # Create a pipeline with preprocessor and the model
#         model_pipeline = Pipeline([
#             ('preprocessor', preprocessor),
#             ('model', RandomForestRegressor(random_state=42))
#         ])

#         # Split the data
#         X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

#         # Train the model
#         model_pipeline.fit(X_train, y_train)

#         # Evaluate the model
#         predictions = model_pipeline.predict(X_test)
#         mse = mean_squared_error(y_test, predictions)
#         r2 = r2_score(y_test, predictions)

#         result_str = f"Mean Squared Error: {mse:.4f}, R^2 Score: {r2:.4f}"
#         print(result_str)
#         return result_str


# import pandas as pd
# from sklearn.model_selection import train_test_split, cross_val_score
# from sklearn.ensemble import RandomForestRegressor
# from sklearn.pipeline import Pipeline
# from sklearn.preprocessing import StandardScaler, OneHotEncoder
# from sklearn.compose import ColumnTransformer
# from sklearn.metrics import mean_squared_error, r2_score
# import numpy as np

# class Model:
#     def __init__(self, data, target, categorical_features, numerical_features):
#         self.data = data
#         self.target = target
#         self.categorical_features = categorical_features
#         self.numerical_features = numerical_features

#     def build_and_evaluate_model(self, cv=5):
#         # Separate the features and the target variable
#         X = self.data.drop(columns=[self.target])
#         y = self.data[self.target]

#         # Create a column transformer for preprocessing
#         preprocessor = ColumnTransformer(
#             transformers=[
#                 ('num', StandardScaler(), self.numerical_features),
#                 ('cat', OneHotEncoder(handle_unknown='ignore'), self.categorical_features)
#             ])

#         # Create a pipeline with preprocessor and RandomForestRegressor
#         model_pipeline = Pipeline([
#             ('preprocessor', preprocessor),
#             ('model', RandomForestRegressor(random_state=42))
#         ])

#         # Perform cross-validation and compute the mean and standard deviation of the scores
#         scores = cross_val_score(model_pipeline, X, y, cv=cv, scoring='neg_mean_squared_error')
#         mean_mse = -np.mean(scores)
#         std_mse = np.std(scores)

#         # Train the model on the entire dataset
#         model_pipeline.fit(X, y)

#         # Results
#         result_str = f"Cross-Validation Mean MSE: {mean_mse:.4f}, Std Dev: {std_mse:.4f}"
#         print(result_str)
#         return result_str


import pandas as pd
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.linear_model import LinearRegression
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error
import numpy as np

class Model:
    def __init__(self, data, target, categorical_features, numerical_features):
        self.data = data
        self.target = target
        self.categorical_features = categorical_features
        self.numerical_features = numerical_features

    def build_and_evaluate_model(self, cv=5):
        # Separate the features and the target variable
        X = self.data.drop(columns=[self.target])
        y = self.data[self.target]

        # Create a column transformer for preprocessing
        preprocessor = ColumnTransformer(
            transformers=[
                ('num', StandardScaler(), self.numerical_features),
                ('cat', OneHotEncoder(handle_unknown='ignore'), self.categorical_features)
            ])

        # Create a pipeline with preprocessor and Linear Regression
        model_pipeline = Pipeline([
            ('preprocessor', preprocessor),
            ('model', LinearRegression())
        ])

        # Perform cross-validation and compute the mean and standard deviation of the scores
        neg_mse_scores = cross_val_score(model_pipeline, X, y, cv=cv, scoring='neg_mean_squared_error')
        rmse_scores = np.sqrt(-neg_mse_scores)
        mean_rmse = np.mean(rmse_scores)
        std_rmse = np.std(rmse_scores)

        # Train the model on the entire dataset
        model_pipeline.fit(X, y)
        predictions = model_pipeline.predict(X)

        # Compute additional metrics
        mse = mean_squared_error(y, predictions)
        r2 = r2_score(y, predictions)
        mae = mean_absolute_error(y, predictions)

        # Results
        result_str = (f"Cross-Validation Mean RMSE: {mean_rmse:.4f}, Std Dev: {std_rmse:.4f}\n"
                      f"MSE: {mse:.4f}\n"
                      f"R2 Score: {r2:.4f}\n"
                      f"MAE: {mae:.4f}")
        print(result_str)
        return result_str

